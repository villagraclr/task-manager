<?php

use App\Providers\AppServiceProvider;
use App\Providers\FortifyServiceProvider;
use App\Modules\Project\Infrastructure\Providers\ProjectServiceProvider;
use App\Modules\Task\Infrastructure\Providers\TaskServiceProvider;
use App\Modules\Comment\Infrastructure\Providers\CommentServiceProvider;

return [
    AppServiceProvider::class,
    FortifyServiceProvider::class,
    ProjectServiceProvider::class,
    TaskServiceProvider::class,
    CommentServiceProvider::class,
];
